import 'package:carieme/constants/theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'pages/splash_1p.dart';
import 'package:carieme/pages/carieUser/service_details/service_details_page.dart';

void main() {
  runApp(
    // ignore: missing_required_param
    ChangeNotifierProvider<DynamicTheme>(
      // ignore: deprecated_member_use
      builder: (_) => DynamicTheme(),
      child: CarieMe(),
    ),
  );
}

class CarieMe extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _CarieMeState();
  }
}

class _CarieMeState extends State<CarieMe> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.black,
        statusBarBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark));
    final themeProvider = Provider.of<DynamicTheme>(context);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Carie Me",
      theme: themeProvider.getDarkMode() ? darkTheme : lightTheme,
      home: /*ServiceDetails(),*/SplashScreen(),
    );
  }
}
