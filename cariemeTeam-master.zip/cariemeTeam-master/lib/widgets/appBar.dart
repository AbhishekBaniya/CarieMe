import 'package:flutter/material.dart';

class AppBarWidget extends StatelessWidget {
  final Widget leading;
  final bool automaticallyImplyLeading;
  final String title;
  final List<Widget> actions;
  final Widget flexibleSpace;
  final double elevation;
  final Color shadowColor;

  final ShapeBorder shape;
  final Color backgroundColor;
  final Brightness brightness;
  final IconThemeData iconTheme;
  final IconThemeData actionsIconTheme;
  final TextTheme textTheme;
  final bool primary;
  final bool centerTitle;
  final bool excludeHeaderSemantics;
  final double toolbarOpacity;
  final double bottomOpacity;
  final double toolbarHeight;

  const AppBarWidget({
    Key key,
    this.leading,
    this.automaticallyImplyLeading = true,
    this.title,
    this.actions,
    this.flexibleSpace,
    this.elevation,
    this.shadowColor,
    this.shape,
    this.backgroundColor,
    this.brightness,
    this.iconTheme,
    this.actionsIconTheme,
    this.textTheme,
    this.primary = true,
    this.centerTitle = true,
    this.excludeHeaderSemantics,
    this.toolbarOpacity = 1.0,
    this.bottomOpacity = 1.0,
    this.toolbarHeight,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
        backgroundColor: Theme.of(context).primaryColorDark,
        elevation: 1.0,
        automaticallyImplyLeading: true,
        iconTheme: Theme.of(context).iconTheme,
        centerTitle: centerTitle,
        title: Text(
          title,
          style: Theme.of(context).textTheme.bodyText2.copyWith(
              fontSize: 20,
              color: Theme.of(context).primaryColorLight,
              fontWeight: FontWeight.bold),
        ),
        actions: [
          Icon(Icons.notification_important,
              color: Theme.of(context).primaryColorLight),
          SizedBox(
            width: 15,
          ),
        ]);
  }
}
