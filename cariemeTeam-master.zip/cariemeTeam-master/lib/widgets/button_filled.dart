import 'package:carieme/constants/colors.dart';
import 'package:flutter/material.dart';

class ButtonFilledWidget extends StatelessWidget {
  final String buttonText;
  final Color buttonColor;
  final Color textColor;
  final VoidCallback onTap;

  const ButtonFilledWidget({
    Key key,
    this.buttonText,
    this.buttonColor,
    this.textColor = Colors.black,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(100),
        ),
        clipBehavior: Clip.antiAlias,
        elevation: 0,
        color: primary4,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(15, 15, 15, 15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                buttonText,
                style:
                    Theme.of(context).textTheme.button.copyWith(color: white1),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
