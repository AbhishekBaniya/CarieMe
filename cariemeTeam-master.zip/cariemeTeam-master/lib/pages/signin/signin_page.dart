import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/widgets/button_unfilled.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:carieme/pages/onboarding/onboarding.dart';


class SignInPage extends StatefulWidget {
  SignInPage({Key key}) : super(key: key);

  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {

  FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController emailInputController;
  TextEditingController pwdInputController;
  final _formKey = new GlobalKey<FormState>();

  @override
  initState() {
    emailInputController = new TextEditingController();
    pwdInputController = new TextEditingController();
    super.initState();
  }

  /**************for login**************/
  Future < FirebaseUser > signIn(String email, String password) async {
    try{
      FirebaseUser user = await _auth.signInWithEmailAndPassword(email: email, password: password);
      assert(user != null);
      assert(await user.getIdToken() != null);
      final FirebaseUser currentUser = await _auth.currentUser();
     /* final prefs = await SharedPreferences.getInstance();
      prefs.setString('current_uid',  user.uid.toString());*/
      if(user.uid == currentUser.uid){
        Navigator.push(context, MaterialPageRoute(builder: (context) => Onboarding(),));
      }
      /*assert(user.uid == currentUser.uid);*/
      return user;
    } catch(e){
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: white1,
      body: Stack(
        children: [
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 200,
                    color: primary4,
                  ),
                  Container(
                    height: 60,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(Strings.LogoWhite),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 100, 40, 0),
                child: TextFieldWidget(
                  hint: Strings.Email,
                  textController: emailInputController,
                  inputType: TextInputType.emailAddress,
                  errorText: validation(emailInputController.text),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 20, 40, 0),
                child: TextFieldWidget(
                  hint: Strings.Password,
                  textController: pwdInputController,
                  inputType: TextInputType.visiblePassword,
                  errorText: validation(pwdInputController.text),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: GestureDetector(
                  onTap: () {
                  },
                  child: Text(
                    Strings.ForgotPassword,
                    style: Theme
                        .of(context)
                        .textTheme
                        .bodyText2
                        .copyWith(color: primary4),
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: ButtonFilledWidget(
              buttonText: Strings.SignIn,
              textColor: white1,
              onTap: () => signIn(emailInputController.text, pwdInputController.text),
            ),
          ),
        ],
      ),
    );
  }

  //for validation
  String validation(String value){
    if(emailInputController.text.isEmpty && pwdInputController.text.isEmpty){
      return "cant be empty";
    } else {
      return null;
    }
  }
/*
  bool validateAndSave() {
    final form = _formKey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    return false;
  }
  // Perform login or signup
  void validateAndSubmit() async {
    setState(() {
      _errorMessage = "";
      _isLoading = true;
    });
    if (validateAndSave()) {
      String userId = "";
      try {
        if (_isLoginForm) {
          userId = await FirebaseAuth.instance.signIn(_email, _password);
          print('Signed in: $userId');
        } else {
          userId = await widget.auth.signUp(_email, _password);
          //widget.auth.sendEmailVerification();
          //_showVerifyEmailSentDialog();
          print('Signed up user: $userId');
        }
        setState(() {
          _isLoading = false;
        });

        *//*if (userId.length > 0 && userId != null && _isLoginForm) {
          widget.loginCallback();
        }*//*
      } catch (e) {
        print('Error: $e');
        setState(() {
          _isLoading = false;
          _errorMessage = e.message;
          _formKey.currentState.reset();
        });
      }
    }
  }*/
}
