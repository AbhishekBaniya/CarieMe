import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/widgets/button_unfilled.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:flutter/material.dart';

class SignInPage extends StatefulWidget {
  SignInPage({Key key}) : super(key: key);

  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: white1,
      body: Stack(
        children: [
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 200,
                    color: primary4,
                  ),
                  Container(
                    height: 60,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(Strings.LogoWhite),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 100, 40, 0),
                child: TextFieldWidget(
                  hint: Strings.Email,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 20, 40, 0),
                child: TextFieldWidget(
                  hint: Strings.Password,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: GestureDetector(
                  onTap: () {},
                  child: Text(
                    Strings.ForgotPassword,
                    style: Theme.of(context)
                        .textTheme
                        .bodyText2
                        .copyWith(color: primary4),
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: ButtonFilledWidget(
              buttonText: Strings.SignIn,
              textColor: white1,
            ),
          ),
        ],
      ),
    );
  }
}
