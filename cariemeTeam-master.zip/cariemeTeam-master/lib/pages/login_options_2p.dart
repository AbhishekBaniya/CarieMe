import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/widgets/button_unfilled.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:flutter/material.dart';

import 'create_account/create_account_page.dart';
import 'signin/signin_page.dart';

class SignInOptions extends StatefulWidget {
  SignInOptions({Key key}) : super(key: key);

  @override
  _SignInOptionsState createState() => _SignInOptionsState();
}

class _SignInOptionsState extends State<SignInOptions> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: Padding(
        padding: const EdgeInsets.only(top: 200),
        child: Column(
          children: [
            Container(
              height: 60,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/main/logoYellow.png"),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 100, 20, 0),
              child: ButtonWidget(
                buttonText: "CREATE ACCOUNT",
                textColor: white1,
                onTap: () {
                  Navigator.push(context, ScaleRoute(page: CreateAccount()));
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: ButtonWidget(
                buttonText: "SIGN IN",
                textColor: white1,
                onTap: () {
                  Navigator.push(context, ScaleRoute(page: SignInPage()));
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 100, 20, 0),
              child: ButtonFilledWidget(
                buttonText: "CONTINUE WITH FACEBOOK",
                textColor: white1,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
              child: ButtonFilledWidget(
                buttonText: "CONTINUE WITH APPLE",
                textColor: white1,
              ),
            ),
            termsAndConditions()
          ],
        ),
      ),
    );
  }

  Widget termsAndConditions() {
    return Container(
      padding: EdgeInsets.fromLTRB(10, 50, 10, 10),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Text(
              "By signing up, you agree to our",
              style: Theme.of(context).textTheme.bodyText2,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                GestureDetector(
                  child: Text(
                    "Data and Privacy Policy",
                    style: Theme.of(context)
                        .textTheme
                        .bodyText2
                        .copyWith(color: primary4, fontWeight: FontWeight.bold),
                  ),
                  onTap: () {
                    print("Show data policy");
                  },
                ),
                Text(
                  " and ",
                  style: Theme.of(context).textTheme.bodyText2,
                ),
              ],
            ),
            GestureDetector(
              child: Text(
                "Terms of Use",
                style: Theme.of(context)
                    .textTheme
                    .bodyText2
                    .copyWith(color: primary4, fontWeight: FontWeight.bold),
              ),
              onTap: () {
                print("Show Cookies Policy");
              },
            ),
          ],
        ),
      ),
    );
  }
}
