import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/add_locations/confirm_location.dart';
import 'package:carieme/pages/carieUser/delivery_types/delivery_types.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:flutter/material.dart';

class OrderDetails extends StatefulWidget {
  OrderDetails({Key key}) : super(key: key);

  @override
  _OrderDetailsState createState() => _OrderDetailsState();
}

class _OrderDetailsState extends State<OrderDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DeliveryTypes(),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Row(
              children: [
                Expanded(
                  flex: 1,
                  child: ButtonFilledWidget(
                    buttonText: Strings.SaveContact,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  flex: 1,
                  child: ButtonFilledWidget(
                    onTap: () {
                      Navigator.push(context, ScaleRoute(page: ConfirmLocation()));
                    },
                    buttonText: Strings.Proceed,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.ServiceDetails);
  }
}
