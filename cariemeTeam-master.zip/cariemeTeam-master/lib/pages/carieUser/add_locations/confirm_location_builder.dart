import 'package:carieme/added/animate_line.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:flutter/material.dart';

class ConfirmLocationBuilder extends StatefulWidget {
  ConfirmLocationBuilder({Key key}) : super(key: key);

  @override
  _ConfirmLocationBuilderState createState() => _ConfirmLocationBuilderState();
}

class _ConfirmLocationBuilderState extends State<ConfirmLocationBuilder> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              flex: 0,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                child: Column(
                  children: [
                    Material(
                      shape: CircleBorder(
                        side: BorderSide(
                            width: 3,
                            color: Theme.of(context).primaryColorDark),
                      ),
                      child: CircleAvatar(
                        radius: 10,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 15,
            ),
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BodyText2CB(
                    data: Strings.StartLocation,
                  ),
                ],
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              flex: 0,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                child: Column(
                  children: [
                    SizedBox(
                      width: 0,
                      height: 140,
                      child: Line(),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 15,
            ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(15, 0, 0, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: BodyText2B(
                            data: Strings.Contact,
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(
                                Icons.edit,
                                color: primary4,
                                size: 15,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              BodyText1C(
                                data: Strings.Edit,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    BodyText1(
                      data: Strings.DName,
                    ),
                    BodyText1(
                      data: Strings.DNumber,
                    ),
                    BodyText1(
                      data: Strings.DEmail,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BodyText2B(
                            data: Strings.Location,
                          ),
                          BodyText1(
                            data: Strings.DAddress,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              flex: 0,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                child: Column(
                  children: [
                    Material(
                      shape: CircleBorder(
                        side: BorderSide(
                            width: 3,
                            color: Theme.of(context).primaryColorDark),
                      ),
                      child: CircleAvatar(
                        radius: 10,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 15,
            ),
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BodyText2CB(
                    data: Strings.DropOffLocation,
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 0,
              child: Icon(
                Icons.remove_circle_outline,
                color: primary4,
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              flex: 0,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                child: Column(
                  children: [
                    SizedBox(
                      width: 0,
                      height: 140,
                      child: Line(),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 15,
            ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(15, 0, 0, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: BodyText2B(
                            data: Strings.Contact,
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(
                                Icons.edit,
                                color: primary4,
                                size: 15,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              BodyText1C(
                                data: Strings.Edit,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    BodyText1(
                      data: Strings.DName,
                    ),
                    BodyText1(
                      data: Strings.DNumber,
                    ),
                    BodyText1(
                      data: Strings.DEmail,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BodyText2B(
                            data: Strings.Location,
                          ),
                          BodyText1(
                            data: Strings.DAddress,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              flex: 0,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                child: Column(
                  children: [
                    Material(
                      shape: CircleBorder(
                        side: BorderSide(
                            width: 3,
                            color: Theme.of(context).primaryColorDark),
                      ),
                      child: CircleAvatar(
                        radius: 10,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 15,
            ),
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BodyText2C(
                    data: Strings.AddADropOff,
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 0,
              child: Icon(
                Icons.add_circle_outline,
                color: primary4,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
