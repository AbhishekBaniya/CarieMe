import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/service_details/service_details_builder.dart';
import 'package:carieme/pages/carieUser/service_details/service_details_page.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ReceiverContactDetails extends StatefulWidget {
  ReceiverContactDetails({Key key}) : super(key: key);

  @override
  _ReceiverContactDetailsState createState() => _ReceiverContactDetailsState();
}

class _ReceiverContactDetailsState extends State<ReceiverContactDetails> {
  final databaseReference = FirebaseDatabase.instance.reference();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController fname;
  TextEditingController lname;
  TextEditingController c_code;
  TextEditingController contact;
  TextEditingController add_location;
  TextEditingController apartment_house_no;
  TextEditingController building_name;
  TextEditingController landmark;
  String user_id = "";


  @override
  initState() {
    fname = new TextEditingController();
    lname = new TextEditingController();
    c_code = new TextEditingController();
    contact = new TextEditingController();
    add_location = new TextEditingController();
    apartment_house_no = new TextEditingController();
    building_name = new TextEditingController();
    landmark = new TextEditingController();
    getUserID();
    super.initState();
  }


  // to get the user_id from firestore
  Future <Firestore> getUserID() async{
    final FirebaseUser user = await _auth.currentUser();
    final uid = user.uid;
    user_id = uid;
    print(user_id);
  }

  //storing data to firestore db
  Future <Firestore> sendData() async{
    if(fname.text.isNotEmpty && lname.text.isNotEmpty && c_code.text.isNotEmpty && contact.text.isNotEmpty && add_location.text.isNotEmpty && apartment_house_no.text.isNotEmpty && building_name.text.isNotEmpty && landmark.text.isNotEmpty){
      Firestore.instance.collection("receiver_contact_details").document(user_id).setData({
        "add_new_contact" : {"fname" : fname.text, "lname" : lname.text},
        "address" : {"location" : add_location.text, "partment_no" : apartment_house_no.text, "building_name" : building_name.text, "landmark" : landmark.text},
        "contact_details" : {"contact" : c_code.text+contact.text},
      }).then((_) => print("add succeeded"));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 30, 20, 10),
                child: BodyText2B(
                  data: Strings.AddFromContactsH,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: TextFieldWidget(
                  hint: Strings.AddFromContactsTF,
                ),
              ),
              // add
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                child: BodyText2B(
                  data: Strings.SearchNewContactH,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: TextFieldWidget(
                  hint: Strings.SearchNewContactTF,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                child: BodyText2B(
                  data: Strings.AddNewContactH,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.FirstName,
                  textController: fname,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.LastName,
                  textController: lname,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: TextFieldWidgetS(
                        hint: Strings.Code,
                        textController: c_code,
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      flex: 2,
                      child: TextFieldWidgetS(
                        hint: Strings.Number,
                        textController: contact,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.AddLocation,
                  textController: add_location,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.ApartmentNumber,
                  textController: apartment_house_no,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.BuildingName,
                  textController: building_name,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.LandMark,
                  textController: landmark,
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Row(
              children: [Expanded(
                  flex: 1,
                  child: ButtonFilledWidget(
                    buttonText: Strings.SaveContact,
                    textColor: Theme.of(context).primaryColorLight,
                    onTap: (){
                      //save Button
                      if(fname.text.isNotEmpty && lname.text.isNotEmpty && c_code.text.isNotEmpty && contact.text.isNotEmpty && add_location.text.isNotEmpty && apartment_house_no.text.isNotEmpty && building_name.text.isNotEmpty && landmark.text.isNotEmpty){
                        sendData();
                        Navigator.push(context, ScaleRoute(page: ServiceDetails()));
                        fname.clear();
                        lname.clear();
                        c_code.clear();
                        contact.clear();
                        add_location.clear();
                        apartment_house_no.clear();
                        building_name.clear();
                        landmark.clear();
                      }
                    },
                  ),
                ),
                SizedBox(width: 10),

                Expanded(
                  flex: 1,
                  child: ButtonFilledWidget(
                    onTap: () {
                      //proceed button
                      if(fname.text.isNotEmpty && lname.text.isNotEmpty && c_code.text.isNotEmpty && contact.text.isNotEmpty && add_location.text.isNotEmpty && apartment_house_no.text.isNotEmpty && building_name.text.isNotEmpty && landmark.text.isNotEmpty){
                        sendData();
                        Navigator.push(context, ScaleRoute(page: ServiceDetails()));
                        fname.clear();
                        lname.clear();
                        c_code.clear();
                        contact.clear();
                        add_location.clear();
                        apartment_house_no.clear();
                        building_name.clear();
                        landmark.clear();
                      }
                    },
                    buttonText: Strings.Proceed,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.ReceiverContactDetails);
  }
}
