import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/service_details/service_details_builder.dart';
import 'package:carieme/pages/carieUser/service_details/service_details_page.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:flutter/material.dart';

class ReceiverContactDetails extends StatefulWidget {
  ReceiverContactDetails({Key key}) : super(key: key);

  @override
  _ReceiverContactDetailsState createState() => _ReceiverContactDetailsState();
}

class _ReceiverContactDetailsState extends State<ReceiverContactDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 30, 20, 10),
                child: BodyText2B(
                  data: Strings.AddFromContactsH,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: TextFieldWidget(
                  hint: Strings.AddFromContactsTF,
                ),
              ),
              // add
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                child: BodyText2B(
                  data: Strings.SearchNewContactH,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: TextFieldWidget(
                  hint: Strings.SearchNewContactTF,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                child: BodyText2B(
                  data: Strings.AddNewContactH,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.FirstName,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.LastName,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: TextFieldWidgetS(
                        hint: Strings.Code,
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      flex: 2,
                      child: TextFieldWidgetS(
                        hint: Strings.Number,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.AddLocation,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.ApartmentNumber,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.BuildingName,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
                child: TextFieldWidgetS(
                  hint: Strings.LandMark,
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Row(
              children: [
                Expanded(
                  flex: 1,
                  child: ButtonFilledWidget(
                    buttonText: Strings.SaveContact,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  flex: 1,
                  child: ButtonFilledWidget(
                    onTap: () {
                      Navigator.push(
                          context, ScaleRoute(page: ServiceDetails()));
                    },
                    buttonText: Strings.Proceed,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.ReceiverContactDetails);
  }
}
