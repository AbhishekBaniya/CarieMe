import 'package:carieme/constants/strings.dart';

import 'package:carieme/widgets/textWidget.dart';
import 'package:flutter/material.dart';

class DeliveryTypes extends StatefulWidget {
  DeliveryTypes({Key key}) : super(key: key);

  @override
  _DeliveryTypesState createState() => _DeliveryTypesState();
}

class _DeliveryTypesState extends State<DeliveryTypes> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(5, 0, 5, 10),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 20,
                    height: 70,
                    child: Image(
                      image: AssetImage(Strings.Walker),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 20,
                    height: 50,
                    child: Image(
                      image: AssetImage(Strings.Bike),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 20,
                    height: 50,
                    child: Image(
                      image: AssetImage(Strings.Motor),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 30,
                    height: 50,
                    child: Image(
                      image: AssetImage(Strings.Sedan),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 30,
                    height: 50,
                    child: Image(
                      image: AssetImage(Strings.SUV),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 30,
                    height: 50,
                    child: Image(
                      image: AssetImage(Strings.Truck),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
