import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/add_locations/confirm_location_builder.dart';
import 'package:carieme/pages/carieUser/assigning_carie_porter/searching_carie_porter.dart';
import 'package:carieme/pages/carieUser/delivery_types/delivery_types.dart';
import 'package:carieme/pages/carieUser/order_details.dart';
import 'package:carieme/pages/carieUser/service_details/service_details_builder.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/button_unfilled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:flutter/material.dart';

class OrderDetailsDashboard extends StatefulWidget {
  OrderDetailsDashboard({Key key}) : super(key: key);

  @override
  _OrderDetailsDashboardState createState() => _OrderDetailsDashboardState();
}

class _OrderDetailsDashboardState extends State<OrderDetailsDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 20, 10, 20),
            child: ListView(
              children: [
                BodyText2B(
                  data: Strings.ServiceDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                ServiceDetailsBuilder(),
                SizedBox(
                  height: 10,
                ),
                BodyText2B(
                  data: Strings.DeliveryDetails,
                ),
                DeliveryTypes(),
                BodyText2B(
                  data: Strings.DeliveryDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                ConfirmLocationBuilder(),
                SizedBox(
                  height: 15,
                ),
                Stack(
                  children: [
                    ButtonWidgetLeft(
                      onTap: () {
                        Navigator.push(
                            context, ScaleRoute(page: OrderDetails()));
                      },
                      buttonText: Strings.Proceed,
                      textColor: Theme.of(context).primaryColorLight,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(140, 0, 0, 0),
                      child: ButtonFilledWidget(
                        onTap: () {
                          Navigator.push(
                              context, ScaleRoute(page: OrderDetails()));
                        },
                        buttonText: Strings.Proceed,
                        textColor: Theme.of(context).primaryColorLight,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Stack(
              children: [
                ButtonWidgetLeft(
                  onTap: () {
                    Navigator.push(context, ScaleRoute(page: OrderDetails()));
                  },
                  buttonText: Strings.Proceed,
                  textColor: Theme.of(context).primaryColorLight,
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(140, 0, 0, 0),
                  child: ButtonFilledWidget(
                    onTap: () {
                      Navigator.push(
                          context, ScaleRoute(page: SearchingCariePorter()));
                    },
                    buttonText: Strings.Proceed,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.OrderDashBoard);
  }
}
