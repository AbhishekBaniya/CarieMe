import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/assigning_carie_porter/track_porter.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:flutter/material.dart';

class OnTheWayCariePorter extends StatefulWidget {
  OnTheWayCariePorter({Key key}) : super(key: key);

  @override
  _OnTheWayCariePorterState createState() => _OnTheWayCariePorterState();
}

class _OnTheWayCariePorterState extends State<OnTheWayCariePorter> {
  bool showCariePorter = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: showCariePorter == true
                ? MainAxisAlignment.start
                : MainAxisAlignment.center,
            children: [
              CircleAvatar(
                backgroundImage: AssetImage(Strings.Motor),
                radius: 70.0,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(30, 0, 30, 30),
                child: BodyText2(
                  data: Strings.BodyOnTheWay,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Column(
              children: [
                showCariePorter == true
                    ? showCariePorterDetails(context)
                    : SizedBox.shrink(),
                ButtonFilledWidget(
                  onTap: () {
                    if (showCariePorter == false) {
                      setState(() {
                        showCariePorter = true;
                      });
                    } else {
                      setState(() {
                        showCariePorter = false;
                      });
                    }
                  },
                  buttonText: Strings.Cancel,
                  textColor: Theme.of(context).primaryColorLight,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget showCariePorterDetails(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      clipBehavior: Clip.antiAlias,
      elevation: 0,
      color: Theme.of(context).primaryColorDark,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(15, 15, 15, 15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage: AssetImage(Strings.Porter),
            ),
            SizedBox(
              height: 15,
            ),
            BodyText2BW(
              data: Strings.DName,
            ),
            BodyText1W(
              data: Strings.DNumber,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                BodyText1W(
                  data: Strings.Bond,
                ),
                BodyText1W(
                  data: Strings.BondAmount,
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                BodyText1W(
                  data: Strings.NumberDeliveries,
                ),
                BodyText1W(
                  data: Strings.TextDeliveries,
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Row(
              children: [
                Expanded(
                  flex: 1,
                  child: Row(
                    children: [
                      Icon(Icons.call),
                      BodyText1W(
                        data: Strings.Call,
                      )
                    ],
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(context, ScaleRoute(page: TrackPorter()));
                    },
                    child: Row(
                      children: [
                        Icon(Icons.location_on),
                        BodyText1W(
                          data: Strings.Track,
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 15,
            ),
          ],
        ),
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.HeaderOnTheWay);
  }
}
