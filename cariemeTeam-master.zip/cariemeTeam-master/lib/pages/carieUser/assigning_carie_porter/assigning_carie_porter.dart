import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:flutter/material.dart';
import 'package:avatar_glow/avatar_glow.dart';

import 'waiting_carie_porter.dart';



class AssigningCariePorter extends StatefulWidget {
  AssigningCariePorter({Key key}) : super(key: key);

  @override
  _AssigningCariePorterState createState() => _AssigningCariePorterState();
}

class _AssigningCariePorterState extends State<AssigningCariePorter> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    AvatarGlow(
                      endRadius: 150,
                      duration: Duration(seconds: 2),
                      glowColor: Theme.of(context).primaryColorDark,
                      repeat: true,
                      repeatPauseDuration: Duration(seconds: 1),
                      startDelay: Duration(seconds: 1),
                      child: Material(
                        elevation: 0.0,
                        shape: CircleBorder(),
                        child: CircleAvatar(
                          backgroundColor: Theme.of(context).primaryColorDark,
                          radius: 60.0,
                        ),
                      ),
                    ),
                    CircleAvatar(
                      backgroundImage: AssetImage(Strings.Motor),
                      radius: 40.0,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(2, 20, 20, 20),
                child: BodyText2(data: Strings.BodyAssigning),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: ButtonFilledWidget(
              onTap: () {
                Navigator.push(context, ScaleRoute(page: WaitingCariePorter()));
              },
              buttonText: Strings.Cancel,
              textColor: Theme.of(context).primaryColorLight,
            ),
          ),
        ],
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.HeaderAssigning);
  }
}
