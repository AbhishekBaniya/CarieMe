import 'package:avatar_glow/avatar_glow.dart';
import 'package:carieme/added/animate_line.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:flutter/material.dart';

class TrackPorter extends StatefulWidget {
  TrackPorter({Key key}) : super(key: key);

  @override
  _TrackPorterState createState() => _TrackPorterState();
}

class _TrackPorterState extends State<TrackPorter> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            image: DecorationImage(image: AssetImage(Strings.Map)),
          ),
        ),
        Positioned(
          left: 100,
          bottom: 200,
          child: SizedBox(
            width: 130,
            height: 500,
            child: Line(),
          ),
        ),
        Positioned(
          left: 90,
          bottom: 700,
          child: Icon(
            Icons.location_on,
            color: primary4,
            size: 40,
          ),
        ),
        Positioned(
          left: 220,
          bottom: 200,
          child: Icon(
            Icons.location_on,
            color: primary4,
            size: 40,
          ),
        ),
        Positioned(
          bottom: 200,
          right: 110,
          child: AvatarGlow(
            endRadius: 100,
            duration: Duration(seconds: 2),
            glowColor: Theme.of(context).primaryColorDark,
            repeat: true,
            repeatPauseDuration: Duration(seconds: 1),
            startDelay: Duration(seconds: 1),
            child: Material(
              elevation: 0.0,
              shape: CircleBorder(),
              child: CircleAvatar(
                backgroundColor: Theme.of(context).primaryColorDark,
                radius: 15.0,
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          right: 20,
          left: 20,
          child: ButtonFilledWidget(
            onTap: () {
              Navigator.pop(context);
            },
            buttonText: Strings.Cancel,
            textColor: Theme.of(context).primaryColorLight,
          ),
        ),
      ],
    );
  }
}
