import 'package:carieme/constants/strings.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:flutter/material.dart';

class BuyForMeForm extends StatefulWidget {
  BuyForMeForm({Key key}) : super(key: key);

  @override
  _BuyForMeFormState createState() => _BuyForMeFormState();
}

class _BuyForMeFormState extends State<BuyForMeForm> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 30, 20, 10),
          child: BodyText2B(
            data: Strings.ItemsDetails,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.ItemDescription,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.Amount,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 3,
                child: TextFieldWidgetS(
                  hint: Strings.StoreName,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.StoreContact,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.StoreLocation,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 3,
                child: TextFieldWidgetS(
                  hint: Strings.Orderer,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.OrdererContact,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 3,
                child: TextFieldWidgetS(
                  hint: Strings.PickUpTime,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.ItemWeight,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.Queuing,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Length,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Width,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Height,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Depth,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
