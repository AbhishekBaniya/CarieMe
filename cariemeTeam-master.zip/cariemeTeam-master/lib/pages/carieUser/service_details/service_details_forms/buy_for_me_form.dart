import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/add_locations/confirm_location.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class BuyForMeForm extends StatefulWidget {
  BuyForMeForm({Key key}) : super(key: key);


  @override
  BuyForMeFormState createState() => BuyForMeFormState();
}

class BuyForMeFormState extends State<BuyForMeForm> {
  final fb = FirebaseDatabase.instance.reference();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final db = Firestore.instance;
  TextEditingController iteam_descController;
  TextEditingController exact_amt_to_be_paidController;
  TextEditingController storeNameController;
  TextEditingController storeContactController;
  TextEditingController storeLocationController;
  TextEditingController whoMadeController;
  TextEditingController contactController;
  TextEditingController picktimeController;
  TextEditingController item_weightController;
  TextEditingController needsController;
  TextEditingController lengthController;
  TextEditingController widthController;
  TextEditingController heightController;
  TextEditingController depthController;
  var user_id;

  @override
  initState() {
    iteam_descController =  TextEditingController();
    exact_amt_to_be_paidController =  TextEditingController();
    storeNameController =  TextEditingController();
    storeContactController =   TextEditingController();
    storeLocationController =  TextEditingController();
    whoMadeController =  TextEditingController();
    contactController =  TextEditingController();
    picktimeController =  TextEditingController();
    item_weightController =  TextEditingController();
    needsController =  TextEditingController();
    lengthController =  TextEditingController();
    widthController =  TextEditingController();;
    heightController =  TextEditingController();
    depthController =  TextEditingController();
    getUserID();
    super.initState();
  }

  // to get the user_id from firestore
  Future <Firestore> getUserID() async{
    var firebaseUser = await FirebaseAuth.instance.currentUser();
    user_id = firebaseUser.uid;
    /*final FirebaseUser user = await _auth.currentUser();
    final uid = user.uid;
    user_id = uid;*/
  }

  Future <Firestore> addData() async{
    CollectionReference reference = Firestore.instance as CollectionReference;
    await reference.add({
      "item_id" : {
        "id" : user_id.toString(), "description" : {
          "item_description" : iteam_descController, "exact_amount_to_be_paid" : exact_amt_to_be_paidController, "details" : {"weight" : item_weightController, "height" : heightController,
            "width" : widthController, "length" : lengthController, "queing" : needsController, "depth" : depthController}},
        "store_details" : {"name" : storeNameController, "contact" : storeContactController, "location": storeLocationController},
        "oreder_from": {"name" : whoMadeController, "contact" : contactController,},
        "pickup":{"time" : picktimeController, "item_description" : iteam_descController, "id" : user_id.toString(),},}
    });
  }

  //setData to fb
  /*Future <Firestore> setData() async{
    *//*if(iteam_descController.text.isNotEmpty && exact_amt_to_be_paidController.text.isNotEmpty &&
        storeNameController.text.isNotEmpty && storeContactController.text.isNotEmpty &&
        storeLocationController.text.isNotEmpty && whoMadeController.text.isNotEmpty &&
        contactController.text.isNotEmpty && picktimeController.text.isNotEmpty &&
        item_weightController.text.isNotEmpty && needsController.text.isNotEmpty &&
        lengthController.text.isNotEmpty && widthController.text.isNotEmpty && heightController.text.isNotEmpty && depthController.text.isNotEmpty)*//*
    Firestore.instance.collection("items").document(user_id).setData({
      "item_id" : {
        "id" : user_id.toString(), "description" : {
          "item_description" : iteam_descController.text, "exact_amount_to_be_paid" : exact_amt_to_be_paidController, "details" : {"weight" : item_weightController, "height" : heightController,
            "width" : widthController, "length" : lengthController, "queing" : needsController, "depth" : depthController}},
        "store_details" : {"name" : storeNameController, "contact" : storeContactController, "location": storeLocationController},
        "oreder_from": {"name" : whoMadeController, "contact" : contactController,},
        "pickup":{"time" : picktimeController, "item_description" : iteam_descController, "id" : user_id.toString(),},},}).then((_) => print("succeed")).catchError(FlutterError.onError);
    *//*else print("something went wrong");*//*
  }*/

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 30, 20, 10),
          child: BodyText2B(
            data: Strings.ItemsDetails,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.ItemDescription,
            textController: iteam_descController,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.Amount,
            textController: exact_amt_to_be_paidController,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 3,
                child: TextFieldWidgetS(
                  hint: Strings.StoreName,
                  textController: storeNameController,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.StoreContact,
                  textController: storeContactController,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.StoreLocation,
            textController: storeLocationController,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 3,
                child: TextFieldWidgetS(
                  hint: Strings.Orderer,
                  textController: whoMadeController,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.OrdererContact,
                  textController: contactController,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 3,
                child: TextFieldWidgetS(
                  hint: Strings.PickUpTime,
                  textController: picktimeController,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.ItemWeight,
                  textController: item_weightController,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 2,
                child: TextFieldWidgetS(
                  hint: Strings.Queuing,
                  textController: needsController,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Length,
                  textController: lengthController,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Width,
                  textController: widthController,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Height,
                  textController: heightController,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Depth,
                  textController: depthController,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  @override
  void dispose() {
    iteam_descController.dispose();
    super.dispose();
  }
}