import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/service_details/service_details_builder.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:flutter/material.dart';

class SendDocumentForm extends StatefulWidget {
  SendDocumentForm({Key key}) : super(key: key);

  @override
  _SendDocumentFormState createState() => _SendDocumentFormState();
}

class _SendDocumentFormState extends State<SendDocumentForm> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 30, 20, 10),
          child: BodyText2B(
            data: Strings.DocumentDetails,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.ItemValue,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.DocumentDescription,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: TextFieldWidgetS(
            hint: Strings.Count,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Length,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: TextFieldWidgetS(
                  hint: Strings.Width,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
