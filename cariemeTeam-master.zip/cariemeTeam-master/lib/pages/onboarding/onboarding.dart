import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/pages/dashboard_pages.dart/user_options.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:flutter/material.dart';

class Onboarding extends StatefulWidget {
  Onboarding({Key key}) : super(key: key);

  @override
  _OnboardingState createState() => _OnboardingState();
}

class _OnboardingState extends State<Onboarding> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: Stack(
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 100.0),
                child: Container(
                  height: 60,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/main/logoYellow.png"),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: ButtonFilledWidget(
                buttonText: "LET'S START",
                textColor: white1,
                onTap: () {
                  Navigator.push(context, ScaleRoute(page: UserOptions()));
                }),
          ),
        ],
      ),
    );
  }
}
