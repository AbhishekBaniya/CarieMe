import 'package:avatar_glow/avatar_glow.dart';
import 'package:carieme/added/animate_line.dart';
import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/add_locations/confirm_location_builder.dart';
import 'package:carieme/pages/carieUser/assigning_carie_porter/searching_carie_porter.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/button_unfilled.dart';
import 'package:flutter/material.dart';

class CarieOrderDetailsPorter extends StatefulWidget {
  CarieOrderDetailsPorter({Key key}) : super(key: key);

  @override
  _CarieOrderDetailsPorterState createState() =>
      _CarieOrderDetailsPorterState();
}

class _CarieOrderDetailsPorterState extends State<CarieOrderDetailsPorter> {
  bool showCariePorter = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              image: DecorationImage(image: AssetImage(Strings.Map)),
            ),
          ),
          Positioned(
            left: 100,
            bottom: 200,
            child: SizedBox(
              width: 130,
              height: 500,
              child: Line(),
            ),
          ),
          Positioned(
            left: 90,
            bottom: 700,
            child: Icon(
              Icons.location_on,
              color: primary4,
              size: 40,
            ),
          ),
          Positioned(
            left: 220,
            bottom: 200,
            child: Icon(
              Icons.location_on,
              color: primary4,
              size: 40,
            ),
          ),
          Positioned(
            bottom: 200,
            right: 110,
            child: AvatarGlow(
              endRadius: 100,
              duration: Duration(seconds: 2),
              glowColor: Theme.of(context).primaryColorDark,
              repeat: true,
              repeatPauseDuration: Duration(seconds: 1),
              startDelay: Duration(seconds: 1),
              child: Material(
                elevation: 0.0,
                shape: CircleBorder(),
                child: CircleAvatar(
                  backgroundColor: Theme.of(context).primaryColorDark,
                  radius: 15.0,
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Column(
              children: [
                showDetails == true
                    ? showCariePorterDetails(context)
                    : SizedBox.shrink(),
                Stack(
                  children: [
                    ButtonWidgetLeft(
                      onTap: () {
                        if (showDetails == false) {
                          setState(() {
                            showDetails = true;
                          });
                        } else {
                          setState(() {
                            showDetails = false;
                          });
                        }
                      },
                      buttonText: Strings.ViewDeatils,
                      textColor: Theme.of(context).primaryColorLight,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(160, 0, 0, 0),
                      child: ButtonFilledWidget(
                        onTap: () {
                          Navigator.push(context,
                              ScaleRoute(page: SearchingCariePorter()));
                        },
                        buttonText: Strings.DeliverThisOrder,
                        textColor: Theme.of(context).primaryColorLight,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool showDetails = false;

  Widget showCariePorterDetails(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      clipBehavior: Clip.antiAlias,
      elevation: 0,
      color: Theme.of(context).primaryColorLight,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(15, 15, 15, 15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ConfirmLocationBuilder(),
            SizedBox(
              height: 15,
            ),
          ],
        ),
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.OrderDetailsHeader);
  }
}
