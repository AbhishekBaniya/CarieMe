import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/carie_order_details_dashboard/order_details_dashboard.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:flutter/material.dart';

class CariePorterVerification extends StatefulWidget {
  CariePorterVerification({Key key}) : super(key: key);

  @override
  _CariePorterVerificationState createState() =>
      _CariePorterVerificationState();
}

class _CariePorterVerificationState extends State<CariePorterVerification> {
  bool searchingMode = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
            child: ListView(
              children: [
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.PersonalInformation,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.FirstName,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.LastName,
                ),
                SizedBox(
                  height: 20,
                ),
                // Contact
                BodyText2B(
                  data: Strings.ContactDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                BodyText1(
                  data: Strings.PrimaryNumber,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: TextFieldWidgetS(
                        hint: Strings.Code,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: TextFieldWidgetS(
                        hint: Strings.DNumber,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                BodyText1(
                  data: Strings.EmergencyContact,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: TextFieldWidgetS(
                        hint: Strings.Code,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: TextFieldWidgetS(
                        hint: Strings.DNumber,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.AddressDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.Address,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.ApartmentNumber,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.BuildingName,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.LandMark,
                ),
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.VehicleDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.VehicleType,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.VehicleModel,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.Year,
                ),
                //Upload
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.UploadImage,
                ),
                SizedBox(
                  height: 10,
                ),
                uploadImages(context),
                SizedBox(
                  height: 50,
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
              child: ButtonFilledWidget(
                onTap: () {
                  Navigator.push(
                      context, ScaleRoute(page: OrderDetailsDashboard()));
                },
                buttonText: Strings.SubmitForVerification,
                textColor: Theme.of(context).primaryColorLight,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget uploadImages(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                  context, ScaleRoute(page: CariePorterVerification()));
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              color: Theme.of(context).primaryColorDark,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(5, 20, 5, 20),
                child: BodyText2BW(
                  textAlign: TextAlign.center,
                  data: Strings.NBIClearance,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                  context, ScaleRoute(page: CariePorterVerification()));
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              color: Theme.of(context).primaryColorDark,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(5, 20, 5, 20),
                child: BodyText2BW(
                  textAlign: TextAlign.center,
                  data: Strings.GovernmentId,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                  context, ScaleRoute(page: CariePorterVerification()));
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              color: Theme.of(context).primaryColorDark,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(5, 20, 5, 20),
                child: Center(
                  child: BodyText2BW(
                    textAlign: TextAlign.center,
                    data: Strings.DriverLicense,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.CariePorterVerificationHeader);
  }
}
