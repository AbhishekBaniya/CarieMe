import 'dart:io';
import 'dart:math';
import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/carieUser/carie_order_details_dashboard/order_details_dashboard.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'carie_porter_dashboard.dart';

class CariePorterVerification extends StatefulWidget {
  CariePorterVerification({Key key}) : super(key: key);

  @override
  _CariePorterVerificationState createState() =>_CariePorterVerificationState();
}

class _CariePorterVerificationState extends State<CariePorterVerification> {
  bool searchingMode = false;
  final databaseReference = FirebaseDatabase.instance.reference();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  FirebaseStorage _storage = FirebaseStorage.instance;
  String user_id ="";
  String url ="";
  String nbiurl ="";
  String govurl ="";
  String licenseurl ="";
  String doc_type = "" ;
  File _image;
  int randomNumber;
  TextEditingController fname;
  TextEditingController lname;
  TextEditingController c_code_e_contact;
  TextEditingController emergency_contact;
  TextEditingController c_code_primar;
  TextEditingController contact_primary;
  TextEditingController c_code_secondary;
  TextEditingController contact_secondary;
  TextEditingController address;
  TextEditingController apartment_house_no;
  TextEditingController building_name;
  TextEditingController landmark;
  TextEditingController vehical_type;
  TextEditingController vehical_model;
  TextEditingController vehical_year;

  @override
  initState() {
    Random random = new Random();
    randomNumber = random.nextInt(100);
    getUserID();
    fname = new TextEditingController();
    lname = new TextEditingController();
    c_code_e_contact = new TextEditingController();
    emergency_contact = new TextEditingController();
    c_code_primar = new TextEditingController();
    contact_primary = new TextEditingController();
    c_code_secondary = new TextEditingController();
    contact_secondary = new TextEditingController();
    address = new TextEditingController();
    apartment_house_no = new TextEditingController();
    building_name = new TextEditingController();
    landmark = new TextEditingController();
    vehical_type = new TextEditingController();
    vehical_model = new TextEditingController();
    vehical_year = new TextEditingController();
    super.initState();
  }

    // to get the user_id from firestore
  Future <Firestore> getUserID() async{
    final FirebaseUser user = await _auth.currentUser();
    final uid = user.uid;
    user_id = uid;
  }

  //send to firestore database
  Future <Firestore> setVerificationData() async{
    if(url.isNotEmpty && fname.text.isNotEmpty && lname.text.isNotEmpty && contact_primary.text.isNotEmpty){
      Firestore.instance.collection("porter_verifications").document(user_id).setData({
        "personal_info":{"fname" : fname.text, "lname" : lname.text,},
        "contact_details" :{"primary" : c_code_primar.text+contact_primary.text, "secondary" : c_code_e_contact.text+emergency_contact.text,},
        "address" :{"address" : address.text, "apartment_house_no" : apartment_house_no.text, "building_name" : building_name.text, "landmark" : landmark.text,},
        "vehical" :{"model" : vehical_model.text, "type" : vehical_type.text, "year" : vehical_year.text,},
        "documents" : {"driving_license": url.toString(), "government_id" : url.toString(), "nbi_clearance" : url.toString(), }});
      if(user_id.isNotEmpty) Navigator.push(context, ScaleRoute(page: CariePorterDashboard()));
        //Navigator.push(context, ScaleRoute(page: OrderDetailsDashboard()));
    } else {
      print("Error");
    }
  }

  Future chooseFile() async {
    await ImagePicker.pickImage(source: ImageSource.gallery).then((image) {
      setState(() {
        _image = image;
        uploadFile();
      });
    });
  }


  Future uploadFile() async {
    StorageReference storageReference = FirebaseStorage.instance.ref().child(doc_type);
    StorageUploadTask uploadTask = storageReference.putFile(_image);
    await uploadTask.onComplete;
    print('File Uploaded');
    storageReference.getDownloadURL().then((fileURL) {
      setState(() {
        url = fileURL;
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
            child: ListView(
              children: [
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.PersonalInformation,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.FirstName,
                  textController: fname,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.LastName,
                  textController: lname,
                ),
                SizedBox(
                  height: 20,
                ),
                // Contact
                BodyText2B(
                  data: Strings.ContactDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                BodyText1(
                  data: Strings.PrimaryNumber,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: TextFieldWidgetS(
                        hint: Strings.Code,
                        textController: c_code_primar,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: TextFieldWidgetS(
                        hint: Strings.DNumber,
                        textController: contact_primary,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                BodyText1(
                  data: Strings.EmergencyContact,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: TextFieldWidgetS(
                        hint: Strings.Code,
                        textController: c_code_e_contact,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: TextFieldWidgetS(
                        hint: Strings.DNumber,
                        textController: emergency_contact,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.AddressDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.Address,
                  textController: address,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.ApartmentNumber,
                  textController: apartment_house_no,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.BuildingName,
                  textController: building_name,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.LandMark,
                  textController: landmark,
                ),
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.VehicleDetails,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.VehicleType,
                  textController: vehical_type,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.VehicleModel,
                  textController: vehical_model,
                ),
                SizedBox(
                  height: 10,
                ),
                TextFieldWidgetS(
                  hint: Strings.Year,
                  textController: vehical_year,
                ),
                //Upload
                SizedBox(
                  height: 20,
                ),
                BodyText2B(
                  data: Strings.UploadImage,
                ),
                SizedBox(
                  height: 10,
                ),
                imageViewer(context),
                uploadImages(context),

                SizedBox(
                  height: 50,
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
              child: ButtonFilledWidget(
                onTap: () {
                  //submit button
                  if(_image !=null && url.toString().isNotEmpty){
                    setVerificationData();
                  }
                },
                buttonText: Strings.SubmitForVerification,
                textColor: Theme.of(context).primaryColorLight,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget imageViewer(BuildContext context){
    return Center(
        child: Column(
            children: <Widget>[
              Container(child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Column(
                        children:<Widget>[Text('Selected Image'),
                          if (_image != null) Image.file(_image, height: 150, width: 150,)
                          else Container(child: Center(child: Text("No Image is Selected",),),
                            height: 200,),],
                    ),
                  ]
                  ,)
                ,)
                ,)
              ,]
        ),
    );
  }

  Widget uploadImages(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: GestureDetector(
            onTap: () {
              if(doc_type.isEmpty){
                doc_type = user_id+"_nbi_"+randomNumber.toString();
               // nbiurl = url;
                chooseFile();
              }
              //Navigator.push(context, ScaleRoute(page: CariePorterVerification()));
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              color: Theme.of(context).primaryColorDark,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(5, 20, 5, 20),
                child: BodyText2BW(
                  textAlign: TextAlign.center,
                  data: Strings.NBIClearance,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: GestureDetector(
            onTap: () {
              if(doc_type.isEmpty){
                doc_type = user_id+"_government_"+randomNumber.toString();
                //govurl = url;
                chooseFile();
              }
              //Navigator.push(context, ScaleRoute(page: CariePorterVerification()));
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              color: Theme.of(context).primaryColorDark,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(5, 20, 5, 20),
                child: BodyText2BW(
                  textAlign: TextAlign.center,
                  data: Strings.GovernmentId,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: GestureDetector(
            onTap: () {
              if(doc_type.isEmpty){
                doc_type = user_id+"_driving_license_"+randomNumber.toString();
                //licenseurl = url;
                chooseFile();
              }
              //Navigator.push(context, ScaleRoute(page: CariePorterVerification()));
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              color: Theme.of(context).primaryColorDark,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(5, 20, 5, 20),
                child: Center(
                  child: BodyText2BW(
                    textAlign: TextAlign.center,
                    data: Strings.DriverLicense,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget appBar() {
    return AppBarWidget(title: Strings.CariePorterVerificationHeader);
  }
}
