import 'package:avatar_glow/avatar_glow.dart';
import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/cariePorter/carie_porter_verification.dart';
import 'package:carieme/pages/cariePorter/track_carie_orders.dart';
import 'package:carieme/pages/carieUser/carie_order_details_dashboard/order_details_dashboard.dart';
import 'package:carieme/widgets/appBar.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class CariePorterDashboard extends StatefulWidget {
  CariePorterDashboard({Key key}) : super(key: key);

  @override
  _CariePorterDashboardState createState() => _CariePorterDashboardState();
}

class _CariePorterDashboardState extends State<CariePorterDashboard> {
  bool searchingMode = false;


  @override
  initState() {

    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: appBar(),
      ),
      body: Stack(
        children: [
          Column(
            children: [
              SizedBox(
                height: 30,
              ),
              Center(
                child: GestureDetector(
                  onLongPress: () {
                    if (searchingMode == false) {
                      setState(() {
                        searchingMode = true;
                      });
                    } else {
                      setState(() {
                        searchingMode = false;
                      });
                    }
                  },
                  onTap: () {
                    Navigator.push(
                        context, ScaleRoute(page: TrackCarieOrders()));
                  },
                  child: AvatarGlow(
                    endRadius: 120,
                    duration: Duration(seconds: 2),
                    glowColor: Theme.of(context).primaryColorLight,
                    repeat: true,
                    repeatPauseDuration: Duration(milliseconds: 500),
                    startDelay: Duration(seconds: 1),
                    child: Material(
                      elevation: 0.0,
                      shape: CircleBorder(),
                      child: CircleAvatar(
                        backgroundColor: searchingMode == true
                            ? Theme.of(context).primaryColorLight
                            : Theme.of(context).primaryColorDark,
                        radius: 50.0,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 50,
              ),
              searchingMode == true
                  ? Column(
                      children: [
                        BodyText2CB(
                          data: Strings.OnlineMode,
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(50, 10, 50, 10),
                          child: BodyText1(
                            textAlign: TextAlign.center,
                            data: Strings.OnlineModeText,
                          ),
                        ),
                      ],
                    )
                  : Column(
                      children: [
                        BodyText2CB(
                          data: Strings.OfflineMode,
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(50, 10, 50, 10),
                          child: BodyText1(
                            textAlign: TextAlign.center,
                            data: Strings.OfflineModeText,
                          ),
                        ),
                      ],
                    ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 30, 20, 0),
                  child: showVerification(context),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                  child: ButtonFilledWidget(
                    onTap: () {
                      Navigator.push(
                          context, ScaleRoute(page: OrderDetailsDashboard()));
                    },
                    buttonText: Strings.FindCarieOrders1,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                  child: ButtonFilledWidget(
                    onTap: () {
                      Navigator.push(
                          context, ScaleRoute(page: OrderDetailsDashboard()));
                    },
                    buttonText: Strings.FindCarieOrders2,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
                  child: ButtonFilledWidget(
                    onTap: () {
                      Navigator.push(
                          context, ScaleRoute(page: OrderDetailsDashboard()));
                    },
                    buttonText: Strings.FindCarieOrders3,
                    textColor: Theme.of(context).primaryColorLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget showVerification(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // carrieporter vaerification
        Navigator.push(context, ScaleRoute(page: CariePorterVerification()));
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        clipBehavior: Clip.antiAlias,
        elevation: 0,
        color: Theme.of(context).primaryColorDark,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(15, 15, 15, 15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              BodyText2BW(
                data: Strings.GetVerified,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                child: BodyText1W(
                  data: Strings.GetVerifiedText,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget appBar() {
    return AppBarWidget(
        title: searchingMode == true
            ? Strings.CariePorterDashboardOnline
            : Strings.CariePorterDashboardOfline);
  }
}
