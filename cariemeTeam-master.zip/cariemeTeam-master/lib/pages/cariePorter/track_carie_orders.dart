import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/cariePorter/carie_porter_order_details.dart';
import 'package:carieme/pages/cariePorter/carie_porter_verification.dart';
import 'package:carieme/widgets/textWidget.dart';
import 'package:flutter/material.dart';

class TrackCarieOrders extends StatefulWidget {
  TrackCarieOrders({Key key}) : super(key: key);

  @override
  _TrackCarieOrdersState createState() => _TrackCarieOrdersState();
}

class _TrackCarieOrdersState extends State<TrackCarieOrders> {
  bool showOrderDetails = false;
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            image: DecorationImage(image: AssetImage(Strings.Map)),
          ),
        ),
        Positioned(
          left: 90,
          bottom: 700,
          child: GestureDetector(
            onTap: () {
              setState(() {
                showOrderDetails = true;
              });
            },
            child: Icon(
              Icons.location_on,
              color: primary4,
              size: 40,
            ),
          ),
        ),
        Positioned(
          left: 220,
          bottom: 200,
          child: Icon(
            Icons.location_on,
            color: primary4,
            size: 40,
          ),
        ),
        showOrderDetails == true
            ? Positioned(
                bottom: 20,
                right: 20,
                left: 20,
                child: showButtonDetails(),
              )
            : SizedBox.shrink()
      ],
    );
  }

  Widget showButtonDetails() {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, ScaleRoute(page: CarieOrderDetailsPorter()));
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(100),
        ),
        clipBehavior: Clip.antiAlias,
        elevation: 0,
        color: Theme.of(context).primaryColorDark,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(0, 10, 10, 10),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: CircleAvatar(
                  radius: 30.0,
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Image(
                        image: AssetImage(Strings.SUV), fit: BoxFit.cover),
                  ),
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    BodyText2BW(
                      data: Strings.DCalcDistance,
                    ),
                    BodyText1W(
                      data: Strings.Location,
                    ),
                    BodyText1W(
                      data: Strings.DAddress,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
