import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/cariePorter/carie_porter_dashboard.dart';
import 'package:carieme/pages/dashboard_pages.dart/dashboard_carieUser.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';


class UserOptions extends StatefulWidget {
  UserOptions({Key key}) : super(key: key);

  @override
  _UserOptionsState createState() => _UserOptionsState();
}

class _UserOptionsState extends State<UserOptions> {
  // Get a reference to the database service
  final databaseReference = FirebaseDatabase.instance.reference();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String user_id ="";
  bool porter = true;
  bool carier = true;

  @override
  initState(){
    getUserID();
    super.initState();
  }


  Future <Firestore> getUserID() async{
    final FirebaseUser user = await _auth.currentUser();
    final uid = user.uid;
    user_id = uid;
  }

  Future <Firestore> setData() async{
    Firestore.instance.collection("users").document(user_id).updateData({"user_type":{"user_id" : user_id, "user_type": "Porter"}}).then((_) => print("success"));
    if(user_id !=null) Navigator.push(context, ScaleRoute(page: CariePorterDashboard()));}
  Future <Firestore> setDataCarier() async{
    Firestore.instance.collection("users").document(user_id).updateData({"user_type":{"user_id" : user_id, "user_type": "Carier"}}).then((_) => print("success"));
    if(user_id !=null) Navigator.push(context, ScaleRoute(page: CarieUserDashboard()));}

  /*void createRecord(){
    databaseReference.child("/users/"+user_id+"/user_type").set({
      'user_id': 'Porter',
      'user_type': user_id,
    });
    *//*databaseReference.child("2").set({
      'title': 'Flutter in Action',
      'description': 'Complete Programming Guide to learn Flutter'
    });*//*
  }*/
  /*void cPorter(){
    user_type = "porter";
    databaseReference.child("users").child(user_id).set({"user_id": user_id, "user_type": user_type});
    Navigator.push(context, ScaleRoute(page: CariePorterDashboard()));
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          cariePorter(context),
          SizedBox(
            height: 50,
          ),
          carieUser(context),
        ],
      ),
    );
  }

  cariePorter(BuildContext context) {
    return Center(
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              if(porter == true )setData();
            },
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(
                  Radius.circular(5),
                ),
              ),
              foregroundDecoration: BoxDecoration(
                border: Border.all(
                  width: 1,
                  color: Theme.of(context).primaryColorDark,
                ),
                borderRadius: BorderRadius.all(
                  Radius.circular(5),
                ),
              ),
              child: Image(
                image: AssetImage(Strings.CariePorter),
              ),
            ),
          ),
          SizedBox(height: 10),
          Text(
            "I am a Carie Porter",
            style: Theme.of(context)
                .textTheme
                .caption
                .copyWith(color: Theme.of(context).primaryColorDark),
          )
        ],
      ),
    );
  }

  carieUser(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if(carier == true)setDataCarier();
      },
      child: Column(
        children: [
          Container(
            width: 250,
            height: 250,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
                Radius.circular(5),
              ),
            ),
            foregroundDecoration: BoxDecoration(
              border: Border.all(
                width: 1,
                color: Theme.of(context).primaryColorDark,
              ),
              borderRadius: BorderRadius.all(
                Radius.circular(5),
              ),
            ),
            child: Image(
              image: AssetImage(Strings.CarieUser),
            ),
          ),
          SizedBox(height: 10),
          Text(
            "I am a Carie User",
            style: Theme.of(context)
                .textTheme
                .caption
                .copyWith(color: Theme.of(context).primaryColorDark),
          )
        ],
      ),
    );
  }
}