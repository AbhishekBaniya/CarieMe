import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/constants/strings.dart';
import 'package:carieme/pages/cariePorter/carie_porter_dashboard.dart';
import 'package:carieme/pages/dashboard_pages.dart/dashboard_carieUser.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:flutter/material.dart';

class UserOptions extends StatefulWidget {
  UserOptions({Key key}) : super(key: key);

  @override
  _UserOptionsState createState() => _UserOptionsState();
}

class _UserOptionsState extends State<UserOptions> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          cariePorter(context),
          SizedBox(
            height: 50,
          ),
          carieUser(context),
        ],
      ),
    );
  }

  cariePorter(BuildContext context) {
    return Center(
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(context, ScaleRoute(page: CariePorterDashboard()));
            },
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(
                  Radius.circular(5),
                ),
              ),
              foregroundDecoration: BoxDecoration(
                border: Border.all(
                  width: 1,
                  color: Theme.of(context).primaryColorDark,
                ),
                borderRadius: BorderRadius.all(
                  Radius.circular(5),
                ),
              ),
              child: Image(
                image: AssetImage(Strings.CariePorter),
              ),
            ),
          ),
          SizedBox(height: 10),
          Text(
            "I am a Carie Porter",
            style: Theme.of(context)
                .textTheme
                .caption
                .copyWith(color: Theme.of(context).primaryColorDark),
          )
        ],
      ),
    );
  }

  carieUser(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, ScaleRoute(page: CarieUserDashboard()));
      },
      child: Column(
        children: [
          Container(
            width: 250,
            height: 250,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
                Radius.circular(5),
              ),
            ),
            foregroundDecoration: BoxDecoration(
              border: Border.all(
                width: 1,
                color: Theme.of(context).primaryColorDark,
              ),
              borderRadius: BorderRadius.all(
                Radius.circular(5),
              ),
            ),
            child: Image(
              image: AssetImage(Strings.CarieUser),
            ),
          ),
          SizedBox(height: 10),
          Text(
            "I am a Carie User",
            style: Theme.of(context)
                .textTheme
                .caption
                .copyWith(color: Theme.of(context).primaryColorDark),
          )
        ],
      ),
    );
  }
}
