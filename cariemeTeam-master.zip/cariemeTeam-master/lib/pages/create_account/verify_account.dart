import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/pages/create_account/otp.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/progress_indicator_widget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class VerifyAccount extends StatefulWidget {
  VerifyAccount({Key key}) : super(key: key);

  @override
  _VerifyAccountState createState() => _VerifyAccountState();
}

class _VerifyAccountState extends State<VerifyAccount> {
  TextEditingController phoneNumberInputController;
  bool isValid = false;

  var verificationId = "";
  var smsCode = "";


  @override
  initState() {
    phoneNumberInputController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme
          .of(context)
          .primaryColorLight,
      body: Stack(
        children: [
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 200,
                    color: primary4,
                  ),
                  Container(
                    height: 60,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/main/logoWhite.png"),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(2, 200, 20, 0),
                child: TextFieldWidget(
                  hint: "+91 1234567890",
                  textController: phoneNumberInputController,
                  autoFocus: true,
                  errorText: validateMobile(phoneNumberInputController.text),
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: ButtonFilledWidget(
              buttonText: "CONTINUE",
              textColor: white1,
              onTap: () {
                CustomProgressIndicatorWidget();// progress
                String phoneNumber = "+91" + phoneNumberInputController.text.toString(); // with (IN) +91 country code
                if(phoneNumber != null){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Otp(mobileNumber: phoneNumber),));
                }
                // Navigator.push(context, ScaleRoute(page: Otp()));
              },
            ),
          ),
        ],
      ),
    );
  }

  // for validation
  /*String validateMobileNumber(String value) {
    if (!(value.length != 10) && value.isNotEmpty) {
      return "Please Enter the Valid Mobile Number";
    }
    return null;
  }*/

  String validateMobile(String value) {
    String pattern = r'(^(?:[+0]9)?[0-9]{10,12}$)';
    RegExp regExp = new RegExp(pattern);
    if (!(value.length == 0) && value.isEmpty) {
      return 'Please enter mobile number';
    }
    else if (!regExp.hasMatch(value)) {
      return 'Please enter valid mobile number';
    }
    return null;
  }
}