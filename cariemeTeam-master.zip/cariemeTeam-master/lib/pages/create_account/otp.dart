import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/pages/onboarding/onboarding.dart';
import 'package:carieme/pages/signin/signin_page.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/progress_indicator_widget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';


class Otp extends StatefulWidget {
  final mobileNumber;
  /*final String mobileNumber;*/
  Otp({Key key, @required this.mobileNumber}) : super(key: key);

  @override
  _OtpState createState() => _OtpState();
}

class _OtpState extends State<Otp> {
  /// Control the input text field.
  TextEditingController _pinEditingController = TextEditingController();

  var verificationId ="";
  var _smsVerificationCode = "";

  @override
  initState() {
    _verifyPhoneNumber(context);
    print("initState");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: Stack(
        children: [
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 200,
                    color: primary4,
                  ),
                  Container(
                    height: 60,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/main/logoWhite.png"),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(2, 200, 20, 0),
                child: TextFieldWidget(
                  hint: "Otp Verification",
                  textController: _pinEditingController,
                  autoFocus: true,
                  inputType: TextInputType.number,
                  errorText: validateOTP(_pinEditingController.text),
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: ButtonFilledWidget(
              buttonText: "VERIFY",
              textColor: white1,
              onTap: () async {
                Navigator.push(context, ScaleRoute(page: SignInPage()));
                //Navigator.push(context, ScaleRoute(page: Onboarding()));
              },
            ),
          ),
        ],
      ),
    );
  }

  /// method to verify phone number and handle phone auth
 Future _verifyPhoneNumber(BuildContext context) async {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    await _auth.verifyPhoneNumber(
        phoneNumber: widget.mobileNumber,
        timeout: Duration(seconds: 5),
        verificationCompleted: (authCredential) => _verificationComplete(authCredential, context),
        verificationFailed: (authException) => _verificationFailed(authException, context),
        codeAutoRetrievalTimeout: (verificationId) => _codeAutoRetrievalTimeout(verificationId),
        // called when the SMS code is sent
        codeSent: (verificationId, [code]) => _smsCodeSent(verificationId, [code]));
  }

  /// will get an AuthCredential object that will help with logging into Firebase.
  _verificationComplete(AuthCredential authCredential, BuildContext context) {
    FirebaseAuth.instance.signInWithCredential(authCredential).then((authResult) {
      /*final snackBar = SnackBar(content: Text("Success!!! UUID is: " + authResult.user.uid));
      Scaffold.of(context).showSnackBar(snackBar);*/
    });
  }

  _smsCodeSent(String verificationId, List<int> code) {
    // set the verification code so that we can use it to log the user in
    _smsVerificationCode = verificationId;
  }

  _verificationFailed(AuthException authException, BuildContext context) {
    final snackBar = SnackBar(content: Text("Exception!! message:" + authException.message.toString()));
    Scaffold.of(context).showSnackBar(snackBar);
  }

  _codeAutoRetrievalTimeout(String verificationId) {
    // set the verification code so that we can use it to log the user in
    _smsVerificationCode = verificationId;
  }

  // for validation
  String validateOTP(String value) {
    if (!(value.length == 6) && value.isNotEmpty) {
      return "OTP Does Not Matched";
    }
    return null;
  }
}