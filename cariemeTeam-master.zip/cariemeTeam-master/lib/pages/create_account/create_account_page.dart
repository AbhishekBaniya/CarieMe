import 'package:carieme/added/scale_route.dart';
import 'package:carieme/constants/colors.dart';
import 'package:carieme/pages/create_account/verify_account.dart';
import 'package:carieme/widgets/button_filled.dart';
import 'package:carieme/widgets/progress_indicator_widget.dart';
import 'package:carieme/widgets/textfield_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CreateAccount extends StatefulWidget {
  CreateAccount({Key key}) : super(key: key);

  @override
  _CreateAccountState createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {
  final GlobalKey<FormState> _registerFormKey = GlobalKey<FormState>();
  TextEditingController firstNameInputController;
  TextEditingController lastNameInputController;
  TextEditingController emailInputController;
  TextEditingController pwdInputController;
  TextEditingController confirmPwdInputController;

  @override
  initState() {
    firstNameInputController = new TextEditingController();
    lastNameInputController = new TextEditingController();
    emailInputController = new TextEditingController();
    pwdInputController = new TextEditingController();
    confirmPwdInputController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: Stack(
        children: [
          Column(
            key: _registerFormKey,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 200,
                    color: primary4,
                  ),
                  Container(
                    height: 60,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/main/logoWhite.png"),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 100, 20, 0),
                child: TextFieldWidget(
                  hint: "First Name",
                  textController: firstNameInputController,
                  inputType: TextInputType.text,
                  errorText: validateName(firstNameInputController.text),
                  
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: TextFieldWidget(
                  hint: "Last Name",
                  textController: lastNameInputController,
                  inputType: TextInputType.text,
                  errorText: validateName(firstNameInputController.text),

                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: TextFieldWidget(
                  hint: "Email",
                  textController: emailInputController,
                  errorText: validateEmail(emailInputController.text),
                  inputType: TextInputType.emailAddress,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: TextFieldWidget(
                  hint: "Password",
                  textController: pwdInputController,
                  inputType: TextInputType.visiblePassword,
                  errorText: validatePassword(pwdInputController.text),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: TextFieldWidget(
                  hint: "Confirm Password",
                  textController: confirmPwdInputController,
                  inputType: TextInputType.visiblePassword,
                  errorText: validatePassword(confirmPwdInputController.text),
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 20,
            right: 20,
            left: 20,
            child: ButtonFilledWidget(
              buttonText: "CREATE ACCOUNT",
              textColor: white1,
              onTap: () {

                if(firstNameInputController != null && lastNameInputController !=null && emailInputController !=null && pwdInputController != null && confirmPwdInputController !=null){
                  if (pwdInputController.text == confirmPwdInputController.text) {
                    FirebaseAuth.instance
                        .createUserWithEmailAndPassword(
                        email: emailInputController.text,
                        password: pwdInputController.text)
                        .then((currentUser) => Firestore.instance
                        .collection("users")
                        .document(currentUser.uid)
                        .setData({
                      "uid": currentUser.uid,
                      "fname": firstNameInputController.text,
                      "surname": lastNameInputController.text,
                      "email": emailInputController.text,
                      "pwd": pwdInputController.text,
                    })
                        .then((result) => {
                      /*Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (context) => HomePage(
                                title:
                                firstNameInputController
                                    .text +
                                    "'s Tasks",
                                uid: currentUser.uid,
                              )),
                              (_) => false),*/
                      firstNameInputController.clear(),
                      lastNameInputController.clear(),
                      emailInputController.clear(),
                      pwdInputController.clear(),
                      confirmPwdInputController.clear()

                    })
                        .catchError((err) => print(err)))
                        .catchError((err) => print(err));
                  } else {
                    CustomProgressIndicatorWidget();
                  }
                }
                if(validateName != null ){
                  Navigator.push(context, ScaleRoute(page: VerifyAccount()));
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  // for validation

  String validateName(String value) {
    if (value.isEmpty)
      return 'Please Enter Name';
    else
      return null;
  }


  String validatePassword(String value) {
    Pattern p = r'^((?=.*[0-9])+(?=.*[a-z])(?=.*[A-Z])+(?=.*[@#$%^&+=])+(?=\\S+$).{8,20}$)';
    RegExp regex = new RegExp(p);
    if (!regex.hasMatch(value))
    /*if (value.length < 16 && value.isEmpty)*/
      return 'Enter Valid Password';
    else
      return null;
  }

  String validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value))
      return 'Enter Valid Email';
    else
      return null;
  }
}