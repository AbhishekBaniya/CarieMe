class FontFamily {
  FontFamily._();
}
