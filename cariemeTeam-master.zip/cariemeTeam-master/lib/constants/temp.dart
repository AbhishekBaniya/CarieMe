// import 'package:carieme/added/scale_route.dart';
// import 'package:carieme/constants/strings.dart';
// import 'package:carieme/widgets/appBar.dart';
// import 'package:carieme/widgets/button_filled.dart';
// import 'package:carieme/widgets/textWidget.dart';
// import 'package:flutter/material.dart';

// class ConfirmLocation extends StatefulWidget {
//   ConfirmLocation({Key key}) : super(key: key);

//   @override
//   _ConfirmLocationState createState() => _ConfirmLocationState();
// }

// class _ConfirmLocationState extends State<ConfirmLocation> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: PreferredSize(
//         preferredSize: Size.fromHeight(60.0),
//         child: appBar(),
//       ),
//       body: Stack(
//         children: [
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(20, 30, 20, 10),
//                 child: BodyText2B(
//                   data: Strings.ServiceDetails,
//                 ),
//               ),
//             ],
//           ),
//           Positioned(
//             bottom: 20,
//             right: 20,
//             left: 20,
//             child: ButtonFilledWidget(
//               onTap: () {
//                 Navigator.push(context, ScaleRoute(page: ConfirmLocation()));
//               },
//               buttonText: Strings.Proceed,
//               textColor: Theme.of(context).primaryColorLight,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget appBar() {
//     return AppBarWidget(title: Strings.ServiceDetails);
//   }
// }
