import 'package:carieme/constants/colors.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'colors.dart';

class DynamicTheme with ChangeNotifier {
  bool isDarkMode = false;
  getDarkMode() => this.isDarkMode;
  void changeDarkMode(isDarkMode) {
    this.isDarkMode = isDarkMode;
    notifyListeners();
  }
}

const String productSans = "ProductSans";
const String roboto = "Roboto";
const String AppFont = "Avenir Next";
const String LogoFont = "Poiret One";

final darkTheme = ThemeData(
  backgroundColor: secondary6,
  primaryColorLight: primary4,
  primaryColorDark: secondary6,
  primaryColor: primary4,
  accentColor: primary1,
  buttonColor: primary4,
  cardColor: primary2,
  indicatorColor: primary1,
  cursorColor: Colors.white,
  iconTheme: IconThemeData(color: white1),
  textTheme: TextTheme(
    button: TextStyle(fontFamily: roboto, color: white1, fontSize: 14),
    bodyText1: TextStyle(fontFamily: roboto, color: white1, fontSize: 14),
    bodyText2: TextStyle(
      fontFamily: roboto,
      color: white1,
      fontSize: 16,
    ),
    caption: TextStyle(
      fontFamily: roboto,
      color: white1,
      fontSize: 20,
    ),
  ),
);

final lightTheme = ThemeData(
  brightness: Brightness.light,
  backgroundColor: primary4,
  primaryColorLight: white1,
  primaryColorDark: primary4,
  primaryColor: primary4,
  accentColor: primary1,
  buttonColor: primary4,
  cardColor: primary2,
  indicatorColor: primary1,
  cursorColor: Colors.white,
  iconTheme: IconThemeData(color: white1),
  textTheme: TextTheme(
    button: TextStyle(fontFamily: roboto, color: white1, fontSize: 14),
    bodyText1: TextStyle(fontFamily: roboto, color: secondary4, fontSize: 14),
    bodyText2: TextStyle(
      fontFamily: roboto,
      color: secondary5,
      fontSize: 16,
    ),
    caption: TextStyle(
      fontFamily: roboto,
      color: secondary6,
      fontSize: 20,
    ),
  ),
);
