import 'package:flutter/material.dart';

import 'dart:ui';

//Primary Colors
Color primary1 = const Color.fromRGBO(255, 255, 0, 1);
Color primary2 = const Color.fromRGBO(252, 207, 0, 1.0);
Color primary3 = const Color.fromRGBO(252, 195, 0, 1.0);
Color primary4 = const Color.fromRGBO(252, 181, 0, 1);

//Secondary Colors
Color secondary1 = const Color.fromRGBO(216, 216, 216, 1.0);
Color secondary2 = const Color.fromRGBO(177, 177, 177, 1.0);
Color secondary3 = const Color.fromRGBO(144, 144, 144, 1.0);
Color secondary4 = const Color.fromRGBO(113, 113, 113, 1.0);
Color secondary5 = const Color.fromRGBO(77, 77, 77, 1.0);
Color secondary6 = const Color.fromRGBO(46, 46, 46, 1.0);

//Whites
Color white1 = const Color.fromRGBO(250, 250, 250, 1);
