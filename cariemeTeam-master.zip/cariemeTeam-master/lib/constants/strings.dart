class Strings {
  Strings._();

  //General
  static const String appName = "CaireMe";
  static const String Password = "Password";
  static const String Email = "Email";
  static const String TermsOfUse = "Terms of Use";
  static const String SignIn = "SIGN IN";
  static const String ForgotPassword = "Forgot your password?";
  static const String SaveContact = "SAVE CONTACT";
  static const String Proceed = "PROCEED";
  static const String Cancel = "CANCEL";
  static const String AddFromContactsH = "Add receiver from contacts";
  static const String AddFromContactsTF = "Select from contacts";
  static const String SearchNewContactH = "Search new contact";
  static const String SearchNewContactTF = "Search for new user";
  static const String AddNewContactH = "Add new contact";
  static const String AddNewConatactTF = "Add new contact";
  static const String FirstName = "First Name";
  static const String LastName = "Last Name";
  static const String Code = "+639";
  static const String Number = "Number";
  static const String AddLocation = "Add Location";
  static const String ApartmentNumber = "Apartment/House Number";
  static const String BuildingName = "Building Name";
  static const String LandMark = "Landmark";
  static const String ReceiverContactDetails = "Receiver Contact Details";
  static const String ServiceDetails = "Choose Service Details";
  static const String DeliveryDetails = "Choose Delivery Details";

  // Forms All
  static const String Length = "Length (inches)";
  static const String Width = "Width (inches)";
  static const String Height = "Height (inches)";
  static const String Depth = "Depth (inches)";
  static const String Edit = "Edit";

  //SendDocumentForm
  static const String DocumentDetails = "Document Details";
  static const String ItemValue = "Item declaired value";
  static const String DocumentDescription = "Document description";

  static const String Count = "Number of documents";
  static const String SizeNote = "Measurements in inches";

  //BuyForMeForm
  static const String ItemsDetails = "Buy for me item item details";
  static const String ItemDescription = "Items description";
  static const String Amount = "Exact amount to be paid";
  static const String StoreName = "Store name";
  static const String StoreLocation = "Store Location";
  static const String StoreContact = "Store contact number";
  static const String Orderer = "Who made the order";
  static const String OrdererContact = "Contact number";
  static const String PickUpTime = "Pickup time";
  static const String ItemsNumber = "Number of items";
  static const String ItemWeight = "Items wight (kg)";
  static const String Queuing = "Needs queuing?";

  //confirmLocation
  static const String ConfirmLocationAppBar = "Confirm Location";
  static const String StartLocation = "Location starting";
  static const String DropOffLocation = "Drop off location";
  static const String AddADropOff = "Add a drop of location";
  static const String Contact = "Contact details";
  static const String Location = "Pinned location";

  //Delivery Details Dashboard
  static const String OrderDashBoard = "Carie Order Details";

  //searching for cariePorter
  static const String HeaderSearching = "Searching";
  static const String BodySearching = "Searching for the nearest Carie Porter";
  static const String HeaderAssigning = "Assigning";
  static const String BodyAssigning = "Assigning to available Carie Porter";
  static const String HeaderWaiting = "Waiting";
  static const String BodyWaiting =
      "Waiting for Carie Porter to accept your request";
  static const String HeaderOnTheWay = "On the way";
  static const String BodyOnTheWay =
      "Your Carie Porter in on the way to your assigned location";

  //CariePorterDetails
  static const String Bond = "Bond";
  static const String BondAmount = "Php 10,000.00";
  static const String Call = "Call Carie Porter";
  static const String Track = "Track Carie Porter";
  static const String Rating = "(4.50)";
  static const String Ratings = "(200)";
  static const String NumberDeliveries = "200";
  static const String TextDeliveries = "Successful Deliveries";

  //Image String
  static const String LogoWhite = "assets/main/logoWhite.png";

  static const String CariePorter = "assets/images/cariePorter.png";
  static const String CarieUser = "assets/images/carieUser.png";
  static const String PickUpParcel = "assets/images/pickupParcel.png";
  static const String SendCash = "assets/images/sendCash.png";
  static const String SendDocuments = "assets/images/sendDocuments.png";
  static const String SendPackage = "assets/images/sendPackage.png";
  static const String SendParcel = "assets/images/sendParcel.png";
  static const String BuyForMe = "assets/images/buyForMe.png";
  static const String Porter = "assets/images/porter.png";
  static const String Map = "assets/images/map.png";
  static const String Walker = "assets/delivery/walker.png";
  static const String Bike = "assets/delivery/bike.png";
  static const String Motor = "assets/delivery/motor.png";
  static const String Sedan = "assets/delivery/sedan.png";
  static const String SUV = "assets/delivery/suv.png";
  static const String Truck = "assets/delivery/truck.png";

  //dummy strings
  static const String DName = "Vikas Gupta";
  static const String DEmail = "vikas_gupta@gmail.com";
  static const String DNumber = "+971568813434";
  static const String DAddress = "497 Evergreen Rd Roseville CA 95673";
  static const String DCalcDistance = "7 Km away";

  // CariePorter
  static const String CariePorterDashboardOnline = "Searching Carie Orders";
  static const String CariePorterDashboardOfline = "You are on Offline Mode";
  static const String OnlineMode = "SEARCHING MODE";
  static const String OnlineModeText =
      "You are on searching mode, you will get notified once there are available Carie Orders nearby. Tap the indicator to shift to Offline Mode";
  static const String OfflineMode = "OFFLINE MODE";
  static const String OfflineModeText =
      "You are on offline mode, you will get not notified once there are available Carie Orders nearby. Tap the indicator to shift to Online Mode";
  static const String FindCarieOrders1 = "FIND CARIE ORDERS ALONG MY WAY";
  static const String FindCarieOrders2 = "VIEW POSTED CARIE ORDERS";
  static const String FindCarieOrders3 = "VIEW SCHEDULED DELIVERIES";
  static const String GetVerified = "GET VERIFIED NOW";
  static const String GetVerifiedText =
      "Get verified and start receiving Carie Orders";

  //Carie Porter Verification
  static const String CariePorterVerificationHeader =
      "Carie Porter Verification";
  static const String PersonalInformation = "Personal Information";
  static const String ContactDetails = "Contact Details";
  static const String PrimaryNumber = "Primary Contact Number";
  static const String EmergencyContact = "Secondary Contact Number";
  static const String AddressDetails = "Address Details";
  static const String Address = "Address";
  static const String VehicleDetails = "Vehicle Details";
  static const String VehicleType = "Vehicle Type";
  static const String VehicleModel = "Vehicle Model";
  static const String Year = "Year";
  static const String NBIClearance = "NBI Clearance";
  static const String GovernmentId = "Government ID";
  static const String DriverLicense = "Driver's License";
  static const String SubmitForVerification = "SUBMIT FOR VERIFICATION";
  static const String UploadImage = "Upload Image";

// Carie Porter Delivery
  static const String OrderDetailsHeader = "Order Details";
  static const String ViewDeatils = "VIEW DETAILS";
  static const String DeliverThisOrder = "DELIVER THIS ORDER";
}
